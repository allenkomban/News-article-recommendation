


import pickle
import pandas as pd
import numpy as np
from pprint import pprint
from sklearn.metrics import classification_report
from collections import defaultdict





model_names = ['multi_lr','decision_tree','multi_NB','BNB'] 


# Generating the metric dataframe from the above model names
df_results = pd.DataFrame()

for model_name in model_names:
    path = f'../data/pickles/df_results_{model_name}.pickle'
    with open(path, 'rb') as data:
        df = pickle.load(data)
    df_results = df_results.append(df)
    
df_results = df_results.reset_index().drop('index', axis=1)

metrics = {
    'accuracy': 'Accuracy',
    'precision_macro': 'Precision (macro)',
    'recall_macro': 'Recall (macro)',    
    'f1_macro': 'F1 (macro)',
    'precision': 'Precision (micro)',
    'recall': 'Recall (micro)',    
    'f1': 'F1 (micro)',
}

for metric in metrics:
    df_results[metrics[metric]] = df_results[f'mean_test_{metric}'].map('{:,.4f}'.format).astype(str)     + df_results[f'std_test_{metric}'].map(' ±{:,.3f}'.format).astype(str)
    
df_results.sort_values('mean_test_f1_macro', inplace=True, ascending=False)


# ## Cross-validation comparison
# 
# Cross-validation results on the training set for selected metrics, feature sets and implemented methods.
# The following results show the mean validation and standard deviation value for each metric.



display(df_results[['model', *metrics.values()]])
print('Note: Precision, Recall and F1 scores exclude the \'IRRELEVANT\' class')
# print(df_results[['model', 'Accuracy', 'Precision (macro)', 'Recall (macro)', 'F1 (macro)']].to_string())


# ## Final results
# 
# Final results for each class calculated on the whole test set using the final selected method with its hyper-parameters.



selected_model = 'multi_lr' 


# Load the selected final model
path = f'../data/pickles/best_{selected_model}.pickle'
with open(path, 'rb') as data:
    final_model = pickle.load(data)
    
# Load the test set
df_test = pd.read_csv('../data/test.csv', index_col=0).reset_index()
X_test = df_test.article_words.values
y_test = df_test.topic.values

# Load labels
labels = sorted(list(set(y_test)))
labels.remove('IRRELEVANT')



y_pred = final_model.predict(X_test)
print(f'Final results using the \'{selected_model}\' model:\n')
print(classification_report(y_test, y_pred, labels=labels))


# ## Final Recommendations


# Get probability vector for predictions
y_pred_prob = final_model.predict_proba(X_test)

# Index of topic classes in our model
model_classes = final_model.classes_.tolist()

# List of correct article ids for each topic
topic_articles = df_test.groupby('topic')['article_number'].apply(lambda x: x.values.tolist()).to_dict()

# Count of correct articles for each topic
topic_counts = {x: len(topic_articles[x]) for x in topic_articles}


# In[11]:


recommendations = {label: [] for label in sorted(list(set(y_test)))}

# Loop through articles
for index, article in enumerate(df_test.article_number.values):
    # The topic we predicted
    pred_class = y_pred[index]
    # The topic it belongs to
    true_class = y_test[index]
    # Index of predicted class
    pred_index = model_classes.index(pred_class)
    # Probability of prediction
    pred_prob = y_pred_prob[index][pred_index]
    # Save recommendation
    recommendations[pred_class].append((article, pred_prob))


results = []
    
for topic in recommendations:
    if topic == 'IRRELEVANT':
        continue
    top_10 = sorted(recommendations[topic][:10], key=lambda x: x[1], reverse=True)
    
    articles = [int(x[0]) for x in top_10]
    
    tp = len(set(articles).intersection(topic_articles[topic]))
    precision = tp / len(articles) if len(articles) > 0 else 0
    recall = tp / topic_counts[topic] if topic_counts[topic] > 0 else 0
    f1 = (2 * precision * recall) / (precision + recall) if (precision + recall) > 0 else 0

    results.append({
        'Topic name': topic,
        'Suggested articles': ','.join([str(x) for x in articles]),
        'Precision': precision,
        'Recall': recall,
        'F1': f1
    })

df_recommend = pd.DataFrame(results, columns=['Topic name', 'Suggested articles', 'Precision', 'Recall', 'F1'])
print(df_recommend.to_string(index=False,formatters={'Precision':'{:,.2f}'.format, 'Recall':'{:,.2f}'.format, 'F1':'{:,.2f}'.format}))

