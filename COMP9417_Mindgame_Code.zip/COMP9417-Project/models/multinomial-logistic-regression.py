

# # Multinomial Logistic Regression
# 
# https://scikit-learn.org/stable/modules/linear_model.html#logistic-regression



from sklearn.linear_model import LogisticRegression
from sklearn.feature_extraction.text import TfidfVectorizer
from imblearn.over_sampling import SMOTE
from imblearn.pipeline import make_pipeline as make_pipeline_imb
from sklearn.model_selection import GridSearchCV
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, classification_report, make_scorer
import pandas as pd
from pprint import pprint
import pickle




model_name = 'multi_lr'



df_train = pd.read_csv('../data/training.csv', index_col=0)
X_train = df_train['article_words'].values
y_train = df_train['topic'].values

print(X_train.shape, y_train.shape)


# ## Setup the scoring
# 
# These metrics will be collected during cross-validation for the training/validation splits. We will use these metrics for model comparison and evaluation. The evaluation metric used for model selection is **macro F1 excluding the 'irrelevant' class**. Using this metric avoids the majority class skewing our model selection while weighting fairly evenly across the remaining relevant classes.

# In[5]:


labels = set(y_train)
labels.remove('IRRELEVANT')
custom_f1 = make_scorer(f1_score, labels=list(labels), average='macro')

scorer = {
    'accuracy': 'accuracy',
    'precision': make_scorer(precision_score, labels=list(labels), average='micro'),
    'recall': make_scorer(recall_score, labels=list(labels), average='micro'),
    'f1': make_scorer(f1_score, labels=list(labels), average='micro'),    
    'precision_macro': make_scorer(precision_score, labels=list(labels), average='macro'),
    'recall_macro': make_scorer(recall_score, labels=list(labels), average='macro'),
    'f1_macro': make_scorer(f1_score, labels=list(labels), average='macro'),
    'custom': custom_f1,
}


# ## Setup the pipeline

# In[6]:


clf = make_pipeline_imb(
    TfidfVectorizer(),
    SMOTE(random_state=0,n_jobs=-1),
    LogisticRegression(random_state=0),
)


# ## Review configurable parameters
# 
# For each step in the pipeline, research what each parameter does and decide on a range to test in our grid search.

# In[7]:


for step in clf.steps:
    print(step[0])
    pprint(step[1].get_params())




grid_params = {
    'logisticregression__C': [0.1, 0.5, 1.0],
    'logisticregression__solver': ['newton-cg', 'lbfgs', 'saga'],
    'tfidfvectorizer__max_features': [20_000],
    'tfidfvectorizer__max_df': [0.5],
    'tfidfvectorizer__sublinear_tf': [True],
    'tfidfvectorizer__lowercase': [False],
}


# ## Execute the grid search




get_ipython().run_cell_magic('time', '', "grid = GridSearchCV(clf,\n                    grid_params,\n                    cv=5,\n                    n_jobs=-1,\n                    scoring=scorer,\n                    refit='custom',\n                    verbose=1,\n                    return_train_score=True)\n\ngrid.fit(X_train, y_train)\n\nprint(f'Best cross-validation score: {grid.best_score_:.2f}')\nprint(f'Best params: {grid.best_params_}')")


# ## Refit the best model 
# 
# Here we take the best model found during cross-validation and fit it with the entire training dataset.


best_clf = grid.best_estimator_
best_clf.fit(X_train, y_train)


# ## Save model and cross-validation statistics



best_idx = grid.cv_results_['params'].index(grid.best_params_)

d = {
    'model': model_name,
}

for metric in scorer:
    for dataset in ['train', 'test']:
        for stat in ['mean', 'std']:
            metric_item = f'{stat}_{dataset}_{metric}'
            d[metric_item] = grid.cv_results_[metric_item][best_idx]

df_models_clf = pd.DataFrame(d, index=[0])

with open(f'../data/pickles/best_{model_name}.pickle', 'wb') as output:
    pickle.dump(best_clf, output)
    
with open(f'../data/pickles/df_results_{model_name}.pickle', 'wb') as output:
    pickle.dump(df_models_clf, output)
    

