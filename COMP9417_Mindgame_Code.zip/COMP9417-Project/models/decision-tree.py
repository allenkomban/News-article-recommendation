

# # Decision Tree

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.tree import DecisionTreeClassifier 
from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, make_scorer
import warnings
from sklearn.model_selection import GridSearchCV
warnings.filterwarnings('ignore')
from imblearn.over_sampling import SMOTE
from imblearn.pipeline import make_pipeline as make_pipeline_imb
import pickle


# Load the datasets
df_train = pd.read_csv('../data/training.csv', index_col=0)

X_train = df_train['article_words'].values
y_train = df_train['topic'].values

assert(len(X_train) == 9500)
assert(len(y_train) == 9500)



labels = set(y_train)
labels.remove('IRRELEVANT')
custom_f1 = make_scorer(f1_score, labels=list(labels), average='macro')

scorer = {
    'accuracy': 'accuracy',
    'precision': make_scorer(precision_score, labels=list(labels), average='micro'),
    'recall': make_scorer(recall_score, labels=list(labels), average='micro'),
    'f1': make_scorer(f1_score, labels=list(labels), average='micro'),    
    'precision_macro': make_scorer(precision_score, labels=list(labels), average='macro'),
    'recall_macro': make_scorer(recall_score, labels=list(labels), average='macro'),
    'f1_macro': make_scorer(f1_score, labels=list(labels), average='macro'),
    'custom': custom_f1,
}


# ### Setup the pipeline


clf = make_pipeline_imb(
    TfidfVectorizer(),
    SMOTE(random_state=0,n_jobs=-1),
    DecisionTreeClassifier( criterion='gini',random_state=0, min_samples_split = 15)
)


parameters = {
    
    'tfidfvectorizer__max_features': [20_000],
    'tfidfvectorizer__max_df': [0.5],
    'tfidfvectorizer__sublinear_tf': (True, False),
    'tfidfvectorizer__lowercase': (True, False),
    'decisiontreeclassifier__min_samples_leaf':[10,12,15,20],
    'decisiontreeclassifier__min_samples_split':[2,4,6],
    'decisiontreeclassifier__splitter':('best', 'random')
}


gs_clf = GridSearchCV(clf, 
                     parameters, 
                     cv=3, 
                     n_jobs=-1, 
                     verbose = 5, 
                     scoring=scorer, 
                     refit='custom', 
                     return_train_score=True)

gs_clf.fit(X_train, y_train)


print(f'Best cross-validation score: {gs_clf.best_score_:.2f}')
print(f'Best params: {gs_clf.best_params_}')


# ### Refitting the best estimatory by grid search


best_clf = gs_clf.best_estimator_
best_clf.fit(X_train, y_train)


# ### Saving the results to a dataframe


model_name ='decision_tree'

best_idx = gs_clf.cv_results_['params'].index(gs_clf.best_params_)

d = {
    'model': model_name,
}

for metric in scorer:
    for dataset in ['train', 'test']:
        for stat in ['mean', 'std']:
            metric_item = f'{stat}_{dataset}_{metric}'
            d[metric_item] = gs_clf.cv_results_[metric_item][best_idx]

df_models_clf = pd.DataFrame(d, index=[0])

with open(f'/Users/ashish/Desktop/UNSW/COMP9417/Project/COMP9417-project/data/pickles/best_{model_name}.pickle', 'wb') as output:
    pickle.dump(best_clf, output)
    
with open(f'/Users/ashish/Desktop/UNSW/COMP9417/Project/COMP9417-project/data/pickles/df_results_{model_name}.pickle', 'wb') as output:
    pickle.dump(df_models_clf, output)
    

